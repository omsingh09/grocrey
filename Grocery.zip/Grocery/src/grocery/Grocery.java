/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grocery;

/**
 *
 * @author sahilshreyas
 */
public class Grocery {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Home h = new Home();
        h.setVisible(true);
    }
    
}
